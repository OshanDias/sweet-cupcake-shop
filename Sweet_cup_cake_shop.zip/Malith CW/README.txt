

SUBMISSION PACKAGE CONTENTS:
----------------------------

1. Documentation/
   - Main_Report.pdf              : Complete system documentation with UML 
                                     diagrams and OOP concepts explanation
   - User_Manual.pdf               : Comprehensive user guide with screenshots
   - UML_Diagrams/                 : All UML diagrams in separate files

2. SourceCode/
   - SweetCupcakeShop/             : Complete NetBeans project with all 
                                     source files

================================================================================
HOW TO RUN THE APPLICATION:
================================================================================

PREREQUISITES:
--------------
- Java Development Kit (JDK) 8 or higher
- NetBeans IDE (recommended) or any Java IDE
- Operating System: Windows/Mac/Linux

OPTION 1: Run from NetBeans
----------------------------
1. Open NetBeans IDE
2. File → Open Project
3. Navigate to: SourceCode/SweetCupcakeShop
4. Select the project and click "Open Project"
5. Right-click on the project → Run
6. Login screen will appear

OPTION 2: Run from Command Line
--------------------------------
1. Navigate to project directory
2. cd SourceCode/SweetCupcakeShop/src
3. Compile: javac sweetcupcakeshop/SweetCupcakeShop.java
4. Run: java sweetcupcakeshop.SweetCupcakeShop

================================================================================
DEFAULT LOGIN CREDENTIALS:
================================================================================

Manager Account:
   Username: admin
   Password: admin123

Cashier Account:
   Username: cashier
   Password: cashier123

================================================================================
SYSTEM FEATURES:
================================================================================

CASHIER FUNCTIONS:
- View all cupcakes in inventory
- Add new cupcakes with categorization
- Search cupcakes by category
- Logout

MANAGER FUNCTIONS:
- All Cashier functions PLUS:
- Create new cashier accounts
- View all system users

================================================================================
TECHNICAL DETAILS:
================================================================================

Programming Language: Java
GUI Framework: Java Swing
Data Storage: Text file-based (data/cupcakes.txt, data/users.txt)
Architecture: Layered (Models, Views, Controllers, Utils)

OOP Concepts Demonstrated:
- Objects and Classes
- Abstraction (Abstract User class)
- Inheritance (Manager → Cashier → User)
- Encapsulation (Private attributes with getters/setters)
- Polymorphism (Method overriding)

Total Source Files: 12 Java classes
Total Lines of Code: ~1,720

================================================================================
TROUBLESHOOTING:
================================================================================

Issue: Application won't start
Solution: Verify Java 8+ is installed (java -version in terminal)

Issue: Cannot login
Solution: Use default credentials (admin/admin123 or cashier/cashier123)

Issue: Cupcakes not loading
Solution: Check if data/ folder exists in project root with cupcakes.txt

Issue: Build errors in NetBeans
Solution: Clean and Build project (Right-click → Clean and Build)

================================================================================
PROJECT STRUCTURE:
================================================================================

SweetCupcakeShop/
├── src/
│   ├── controllers/
│   │   └── SystemController.java
│   ├── models/
│   │   ├── Category.java
│   │   ├── User.java
│   │   ├── Cashier.java
│   │   ├── Manager.java
│   │   └── Cupcake.java
│   ├── utils/
│   │   └── FileHandler.java
│   ├── views/
│   │   ├── LoginFrame.java
│   │   ├── CashierDashboard.java
│   │   ├── ManagerDashboard.java
│   │   ├── AddCupcakeDialog.java
│   │   └── SearchDialog.java
│   └── sweetcupcakeshop/
│       └── SweetCupcakeShop.java
│
├── data/                    (Auto-created at runtime)
│   ├── cupcakes.txt
│   └── users.txt
│
├── build/
└── nbproject/





For technical support or questions, please refer to the User Manual  
